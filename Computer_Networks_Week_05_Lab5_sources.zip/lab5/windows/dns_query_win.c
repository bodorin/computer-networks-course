/* dns_query_win.c - build a DNS query by hand and send it over UDP
   with Winsock (Computer Networks, Lab 5)
   usage: dns_query_win name [type] [server] [port]
   e.g.   dns_query_win www.kernel.org AAAA 1.1.1.1                       */
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <winsock2.h>
#include <ws2tcpip.h>
#define strcasecmp _stricmp

static const struct { const char *name; int code; } types[] = {
    {"A", 1}, {"NS", 2}, {"CNAME", 5}, {"SOA", 6},
    {"PTR", 12}, {"MX", 15}, {"TXT", 16}, {"AAAA", 28} };
#define NTYPES (int)(sizeof types / sizeof types[0])

static const char *type_name(int code) {
    for (int i = 0; i < NTYPES; i++)
        if (types[i].code == code) return types[i].name;
    return "?";
}

/* Read a 16-bit number stored in network byte order. */
static uint16_t get16(const unsigned char *p) {
    return (uint16_t)(p[0] << 8 | p[1]);
}

/* Read a (possibly compressed) name at msg[*pos] into out and move *pos
   past it. A byte 11xxxxxx starts a 2-byte pointer to an earlier name. */
static int read_name(const unsigned char *msg, int len, int *pos,
                     char *out, int cap) {
    int p = *pos, jumped = 0, n = 0, hops = 0;
    for (;;) {
        if (p >= len || hops++ > 50) return -1;
        int l = msg[p];
        if ((l & 0xC0) == 0xC0) {                 /* pointer: 14-bit offset */
            if (p + 1 >= len) return -1;
            if (!jumped) *pos = p + 2;
            p = ((l & 0x3F) << 8) | msg[p + 1];
            jumped = 1;
            continue;
        }
        if (l == 0) {                             /* root label: the end */
            if (!jumped) *pos = p + 1;
            break;
        }
        if (p + 1 + l > len || n + l + 2 > cap) return -1;
        memcpy(out + n, msg + p + 1, l);          /* copy one label */
        n += l;
        out[n++] = '.';
        p += 1 + l;
    }
    if (n == 0) strcpy(out, ".");                 /* the root itself */
    else out[n - 1] = '\0';                       /* drop the final dot */
    return 0;
}

int main(int argc, char *argv[]) {
    if (argc < 2) {
        fprintf(stderr, "usage: %s name [type] [server] [port]\n", argv[0]);
        return 1;
    }
    const char *qname = argv[1], *server = argc > 3 ? argv[3] : "1.1.1.1";
    int qtype = 0, port = argc > 4 ? atoi(argv[4]) : 53;
    for (int i = 0; i < NTYPES; i++)
        if (strcasecmp(argc > 2 ? argv[2] : "A", types[i].name) == 0)
            qtype = types[i].code;
    if (!qtype) { fprintf(stderr, "unknown type\n"); return 1; }

    /* --- the query: a 12-byte header, then the question;
           every number in network byte order --- */
    unsigned char q[512];
    int n = 0;
    srand((unsigned)time(NULL) ^ (unsigned)GetCurrentProcessId());
    uint16_t id = (uint16_t)rand();
    uint16_t hdr[6] = { htons(id), htons(0x0100), /* flags: RD = 1 */
                        htons(1), 0, 0, 0 };      /* one question */
    memcpy(q, hdr, 12);
    n = 12;
    /* the name as labels: www.kernel.org -> 3 www 6 kernel 3 org 0 */
    for (const char *s = qname; *s; ) {
        const char *dot = strchr(s, '.');
        size_t l = dot ? (size_t)(dot - s) : strlen(s);
        if (l == 0 || l > 63 || n + l + 6 > sizeof q) {
            fprintf(stderr, "bad name\n");
            return 1;
        }
        q[n++] = (unsigned char)l;
        memcpy(q + n, s, l);
        n += (int)l;
        s += l + (dot ? 1 : 0);
    }
    q[n++] = 0;
    uint16_t tc[2] = { htons((uint16_t)qtype), htons(1) };  /* QCLASS IN */
    memcpy(q + n, tc, 4);
    n += 4;
    printf("query (%d bytes):", n);
    for (int i = 0; i < n; i++) printf(" %02x", q[i]);
    printf("\n");

    /* --- one UDP datagram out, one back: no connection, no handshake --- */
    WSADATA wsa;
    if (WSAStartup(MAKEWORD(2, 2), &wsa) != 0) return 1;
    SOCKET fd = socket(AF_INET, SOCK_DGRAM, 0);
    struct sockaddr_in to = {0};
    to.sin_family = AF_INET;
    to.sin_port = htons((uint16_t)port);
    if (inet_pton(AF_INET, server, &to.sin_addr) != 1) {
        fprintf(stderr, "the server must be an IPv4 address\n");
        return 1;
    }
    DWORD tv = 2000;                 /* Winsock: milliseconds, not timeval */
    setsockopt(fd, SOL_SOCKET, SO_RCVTIMEO, (const char *)&tv, sizeof tv);
    unsigned char r[4096];
    int len = -1;
    for (int attempt = 1; attempt <= 3 && len < 0; attempt++) {
        sendto(fd, (const char *)q, n, 0, (struct sockaddr *)&to, sizeof to);
        len = recvfrom(fd, (char *)r, sizeof r, 0, NULL, NULL);
        if (len < 0) printf("no answer after 2 s (attempt %d, error %d)\n",
                            attempt, WSAGetLastError());
    }                                       /* UDP may lose it: we retry */
    closesocket(fd);
    WSACleanup();
    if (len < 12) return 1;

    uint16_t f[6];                          /* the header, in host order */
    for (int i = 0; i < 6; i++) f[i] = get16(r + 2 * i);
    if (f[0] != id) { fprintf(stderr, "wrong id\n"); return 1; }
    printf("response (%d bytes): id=0x%04x flags=0x%04x rcode=%d%s%s\n",
           len, f[0], f[1], f[1] & 0xF, (f[1] & 0x0400) ? " AA" : "",
           (f[1] & 0x0200) ? " TC" : "");
    printf("question=%d answer=%d authority=%d additional=%d\n",
           f[2], f[3], f[4], f[5]);

    int pos = 12;
    char name[256];
    for (int i = 0; i < f[2]; i++) {        /* skip the question(s) */
        if (read_name(r, (int)len, &pos, name, sizeof name) < 0) return 1;
        pos += 4;
    }
    for (int i = 0; i < f[3] + f[4] + f[5]; i++) {   /* resource records */
        if (read_name(r, (int)len, &pos, name, sizeof name) < 0) return 1;
        if (pos + 10 > len) return 1;
        uint16_t t = get16(r + pos), rdlen = get16(r + pos + 8);
        uint32_t ttl = (uint32_t)get16(r + pos + 4) << 16 | get16(r + pos + 6);
        pos += 10;
        if (pos + rdlen > len) return 1;
        char val[256] = "", ex[200];
        int vp = pos;
        if (t == 1 && rdlen == 4)
            inet_ntop(AF_INET, r + pos, val, sizeof val);
        else if (t == 28 && rdlen == 16)
            inet_ntop(AF_INET6, r + pos, val, sizeof val);
        else if (t == 2 || t == 5 || t == 12)       /* NS, CNAME, PTR */
            read_name(r, (int)len, &vp, val, sizeof val);
        else if (t == 15) {                         /* MX: preference, name */
            vp += 2;
            read_name(r, (int)len, &vp, ex, sizeof ex);
            snprintf(val, sizeof val, "%d %s", get16(r + pos), ex);
        } else if (t == 16)                         /* TXT: first string */
            snprintf(val, sizeof val, "\"%.*s\"", r[pos],
                     (const char *)r + pos + 1);
        else
            snprintf(val, sizeof val, "(%d bytes of data)", rdlen);
        const char *sec = i < f[3] ? "answer"
                        : i < f[3] + f[4] ? "authority" : "additional";
        printf("%-10s %-26s %6u  %-5s %s\n", sec, name, ttl,
               type_name(t), val);
        pos += rdlen;
    }
    return 0;
}
