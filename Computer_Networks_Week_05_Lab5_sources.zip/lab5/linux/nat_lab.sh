#!/bin/sh
# nat_lab.sh - a home network, a NAT router and a server inside one Linux
# machine, built from network namespaces (Lab 5).
# usage: sudo ./nat_lab.sh up | down
#
#  [lan] 192.168.77.2 --- 192.168.77.1 [router]                (private side)
#                         203.0.113.1  [router] --- 203.0.113.10 [server]
#                         the router masquerades: NAT        (public side)
set -e
if [ "$1" = "down" ]; then
    for ns in lan router server; do ip netns del $ns 2>/dev/null || true; done
    echo "removed"; exit 0
fi
[ "$1" = "up" ] || { echo "usage: $0 up | down"; exit 1; }

for ns in lan router server; do
    ip netns add $ns; ip -n $ns link set lo up
done
# two virtual cables: lan <-> router and router <-> server
ip link add veth-lan netns lan type veth peer name veth-in netns router
ip link add veth-out netns router type veth peer name veth-srv netns server

ip -n lan    addr add 192.168.77.2/24 dev veth-lan
ip -n router addr add 192.168.77.1/24 dev veth-in
ip -n router addr add 203.0.113.1/24  dev veth-out
ip -n server addr add 203.0.113.10/24 dev veth-srv
ip -n lan    link set veth-lan up
ip -n router link set veth-in up
ip -n router link set veth-out up
ip -n server link set veth-srv up

ip -n lan route add default via 192.168.77.1     # the lan's default gateway
ip netns exec router sysctl -q -w net.ipv4.ip_forward=1
# The server has no route back to 192.168.77.0/24: without NAT its
# replies could not return.

# NAT: packets leaving towards the public side get the router's address
ip netns exec router nft -f - <<'NFT'
table ip nat {
    chain postrouting {
        type nat hook postrouting priority srcnat; policy accept;
        oifname "veth-out" ip saddr 192.168.77.0/24 masquerade
    }
}
NFT
echo "ready: lan 192.168.77.2 -> router (NAT) -> server 203.0.113.10"
