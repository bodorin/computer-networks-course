"""talk.py - type a text protocol by hand: lines go out with CR LF, every
line received is printed (a small "nc -C" that also speaks TLS) (Lab 5).
usage: python3 talk.py host port [--tls]
e.g.   python3 talk.py 127.0.0.1 8025           (SMTP to the lab server)
       python3 talk.py imap.gmail.com 993 --tls (IMAP over TLS)"""
import socket, ssl, sys, threading

host, port = sys.argv[1], int(sys.argv[2])
sock = socket.create_connection((host, port), timeout=10)
if "--tls" in sys.argv:                       # TLS from the first byte
    sock = ssl.create_default_context().wrap_socket(sock, server_hostname=host)
sock.settimeout(None)


def reader():
    for line in sock.makefile("rb"):
        print("<-", line.decode(errors="replace").rstrip("\r\n"), flush=True)
    print("(connection closed by the server)", flush=True)


listener = threading.Thread(target=reader, daemon=True)
listener.start()
try:
    for line in sys.stdin:                    # one typed line = one command
        sock.sendall(line.rstrip("\r\n").encode() + b"\r\n")
    listener.join(5)               # end of input: wait for the last replies
except (KeyboardInterrupt, OSError):
    pass
