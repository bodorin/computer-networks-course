"""stun_client.py - ask a STUN server which public address and port your
UDP packets come from, i.e. which mapping your NAT created (Lab 5).
usage: python3 stun_client.py [server] [port]
       (default stun.l.google.com 19302; RFC 8489 Binding request)"""
import os, socket, struct, sys

server = sys.argv[1] if len(sys.argv) > 1 else "stun.l.google.com"
port = int(sys.argv[2]) if len(sys.argv) > 2 else 19302
MAGIC = 0x2112A442

sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
sock.settimeout(3)
sock.bind(("0.0.0.0", 0))
print("local (private) side:", sock.getsockname())
for attempt in range(2):                  # two requests from the same socket
    tid = os.urandom(12)                  # transaction id
    request = struct.pack("!HHI", 0x0001, 0, MAGIC) + tid   # Binding request
    sock.sendto(request, (server, port))
    data, src = sock.recvfrom(2048)
    mtype, length, magic = struct.unpack("!HHI", data[:8])
    assert data[8:20] == tid and mtype == 0x0101, "not our Binding response"
    pos = 20
    while pos < 20 + length:              # attributes: type, length, value
        atype, alen = struct.unpack("!HH", data[pos:pos + 4])
        value = data[pos + 4:pos + 4 + alen]
        if atype == 0x0020:               # XOR-MAPPED-ADDRESS
            xport = struct.unpack("!H", value[2:4])[0] ^ (MAGIC >> 16)
            xaddr = struct.unpack("!I", value[4:8])[0] ^ MAGIC
            print(f"request {attempt + 1}: the server saw us as "
                  f"{socket.inet_ntoa(struct.pack('!I', xaddr))}:{xport}")
        pos += 4 + (alen + 3) // 4 * 4    # values are padded to 4 bytes
