"""pop3_server.py - a minimal POP3 server over a Maildir (Lab 5).
Teaching code: one user (bob / secret), no TLS.
usage: python3 pop3_server.py maildir [port]   (127.0.0.1, default 1110)"""
import socket, sys, threading
from pathlib import Path

USER, PASSWORD = "bob", "secret"
maildir = Path(sys.argv[1])
port = int(sys.argv[2]) if len(sys.argv) > 2 else 1110


def session(conn):
    def send(line):
        conn.sendall(line.encode() + b"\r\n")

    send("+OK POP3 teaching server ready")
    state, user, deleted, msgs = "AUTHORIZATION", None, set(), []
    for raw in conn.makefile("rb"):
        words = raw.decode(errors="replace").split()
        cmd, args = (words[0].upper(), words[1:]) if words else ("", [])
        if cmd == "QUIT":
            if state == "TRANSACTION":      # UPDATE state: delete only now
                for i in deleted:
                    msgs[i - 1].unlink()
            send(f"+OK bye ({len(deleted)} message(s) deleted)")
            break
        if state == "AUTHORIZATION":
            if cmd == "USER" and args:
                user = args[0]
                send("+OK send PASS")
            elif cmd == "PASS" and user == USER and args == [PASSWORD]:
                msgs = sorted(p for p in (maildir / "new").iterdir())
                state = "TRANSACTION"
                send(f"+OK {len(msgs)} message(s)")
            else:
                send("-ERR authentication failed")
            continue
        live = [i for i in range(1, len(msgs) + 1) if i not in deleted]
        size = lambda i: msgs[i - 1].stat().st_size
        n = int(args[0]) if args and args[0].isdigit() else 0
        if cmd == "STAT":
            send(f"+OK {len(live)} {sum(size(i) for i in live)}")
        elif cmd in ("LIST", "UIDL") and not args:
            send("+OK")
            for i in live:
                uid = msgs[i - 1].name.split(".")[0]
                send(f"{i} {size(i) if cmd == 'LIST' else uid}")
            send(".")
        elif cmd in ("RETR", "TOP") and n in live:
            lines = msgs[n - 1].read_bytes().split(b"\n")
            if cmd == "TOP":            # TOP n k: header + first k lines
                k = int(args[1]) if len(args) > 1 else 0
                blank = lines.index(b"") if b"" in lines else len(lines)
                lines = lines[:blank + 1 + k]
            send("+OK message follows")
            for line in lines:
                line = line.rstrip(b"\r")
                if line.startswith(b"."):
                    line = b"." + line          # dot-stuffing
                conn.sendall(line + b"\r\n")
            send(".")                           # end of the message
        elif cmd == "DELE" and n in live:
            deleted.add(n)
            send(f"+OK message {n} marked for deletion")
        elif cmd == "RSET":
            deleted.clear()
            send("+OK")
        elif cmd == "NOOP":
            send("+OK")
        else:
            send("-ERR unknown command or no such message")
    conn.close()


srv = socket.create_server(("127.0.0.1", port))
print(f"POP3 on 127.0.0.1:{port}, mailbox {maildir}/new")
while True:
    c, _ = srv.accept()
    threading.Thread(target=session, args=(c,), daemon=True).start()
