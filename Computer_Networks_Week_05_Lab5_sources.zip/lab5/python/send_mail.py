"""send_mail.py - send a MIME message with an attachment over SMTP (Lab 5).
usage: python3 send_mail.py [server] [port] [attachment]
       (default server 127.0.0.1, port 8025)"""
import mimetypes, smtplib, sys
from email.message import EmailMessage
from pathlib import Path

server = sys.argv[1] if len(sys.argv) > 1 else "127.0.0.1"
port = int(sys.argv[2]) if len(sys.argv) > 2 else 8025

msg = EmailMessage()                         # the RFC 5322 header fields
msg["From"] = "Alice Student <alice@lab.test>"
msg["To"] = "Bob Teacher <bob@lab.test>"
msg["Subject"] = "Lab 5 report — first draft"     # non-ASCII: RFC 2047
msg.set_content("Hello Bob,\n\nthe report is attached.\n\nAlice\n")
if len(sys.argv) > 3:                 # MIME: the body becomes multipart
    path = Path(sys.argv[3])
    ctype = mimetypes.guess_type(path.name)[0] or "application/octet-stream"
    maintype, subtype = ctype.split("/", 1)
    msg.add_attachment(path.read_bytes(), maintype=maintype,
                       subtype=subtype, filename=path.name)

with smtplib.SMTP(server, port) as smtp:
    smtp.set_debuglevel(1)                   # show the SMTP dialogue
    smtp.ehlo("client.lab.test")
    # the envelope (MAIL FROM, RCPT TO) is separate from From:/To:
    smtp.send_message(msg, from_addr="alice@lab.test",
                      to_addrs=["bob@lab.test"])
