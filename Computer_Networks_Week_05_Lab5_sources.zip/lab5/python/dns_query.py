"""dns_query.py - the same DNS query with Python's struct and UDP (Lab 5).
usage: python3 dns_query.py name [type] [server] [port]"""
import random, socket, struct, sys

TYPES = {"A": 1, "NS": 2, "CNAME": 5, "SOA": 6,
         "PTR": 12, "MX": 15, "TXT": 16, "AAAA": 28}
NAMES = {v: k for k, v in TYPES.items()}


def read_name(msg, pos):
    """Return (name, position after it), following compression pointers."""
    labels, end = [], None
    while True:
        length = msg[pos]
        if length & 0xC0 == 0xC0:              # pointer to an earlier name
            if end is None:
                end = pos + 2
            pos = struct.unpack("!H", msg[pos:pos + 2])[0] & 0x3FFF
            continue
        if length == 0:
            name = ".".join(labels) or "."
            return name, (end if end is not None else pos + 1)
        labels.append(msg[pos + 1:pos + 1 + length].decode())
        pos += 1 + length


name = sys.argv[1]
qtype = TYPES[(sys.argv[2] if len(sys.argv) > 2 else "A").upper()]
server = sys.argv[3] if len(sys.argv) > 3 else "1.1.1.1"
port = int(sys.argv[4]) if len(sys.argv) > 4 else 53

qid = random.randint(0, 0xFFFF)
query = struct.pack("!6H", qid, 0x0100, 1, 0, 0, 0)   # "!": network order
query += b"".join(bytes([len(p)]) + p.encode() for p in name.split("."))
query += b"\0" + struct.pack("!2H", qtype, 1)          # QTYPE, QCLASS IN
print(f"query ({len(query)} bytes):", query.hex(" "))

sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
sock.settimeout(2)
sock.sendto(query, (server, port))
msg, _ = sock.recvfrom(4096)

rid, flags, qd, an, ns, ar = struct.unpack("!6H", msg[:12])
assert rid == qid, "wrong id"
print(f"response ({len(msg)} bytes): flags=0x{flags:04x} rcode={flags & 15}"
      f" answer={an} authority={ns} additional={ar}")
pos = 12
for _ in range(qd):
    _, pos = read_name(msg, pos)
    pos += 4
for i in range(an + ns + ar):
    rname, pos = read_name(msg, pos)
    rtype, _, ttl, rdlen = struct.unpack("!HHIH", msg[pos:pos + 10])
    pos += 10
    rdata = msg[pos:pos + rdlen]
    if rtype == 1:
        value = socket.inet_ntop(socket.AF_INET, rdata)
    elif rtype == 28:
        value = socket.inet_ntop(socket.AF_INET6, rdata)
    elif rtype in (2, 5, 12):
        value = read_name(msg, pos)[0]
    elif rtype == 15:
        pref = struct.unpack("!H", rdata[:2])[0]
        value = f"{pref} {read_name(msg, pos + 2)[0]}"
    elif rtype == 16:
        value = '"' + rdata[1:1 + rdata[0]].decode() + '"'
    else:
        value = f"({rdlen} bytes of data)"
    section = ("answer" if i < an else
               "authority" if i < an + ns else "additional")
    print(f"{section:10} {rname:26} {ttl:6}  {NAMES.get(rtype, '?'):5} {value}")
    pos += rdlen
