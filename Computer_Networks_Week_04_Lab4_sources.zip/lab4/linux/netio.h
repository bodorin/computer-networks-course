/* netio.h - helpers for TCP byte streams (Computer Networks, Labs 3-4) */
#ifndef NETIO_H
#define NETIO_H
#include <stdint.h>
#include <errno.h>
#include <string.h>
#include <unistd.h>
#include <netdb.h>
#include <arpa/inet.h>
#include <sys/socket.h>

/* Write exactly len bytes. Returns 0 on success, -1 on error. */
static inline int send_all(int fd, const void *buf, size_t len) {
    const char *p = buf;
    while (len > 0) {
        ssize_t n = send(fd, p, len, 0);
        if (n < 0) { if (errno == EINTR) continue; return -1; }
        p += n; len -= (size_t)n;
    }
    return 0;
}

/* Read one line ending in LF (CR LF is removed). Returns its length,
   0 if the peer closed before any byte, -1 on error or too long a line. */
static inline long recv_line(int fd, char *buf, size_t cap) {
    size_t n = 0;
    for (;;) {
        char ch;
        ssize_t r = recv(fd, &ch, 1, 0);
        if (r < 0) { if (errno == EINTR) continue; return -1; }
        if (r == 0) { if (n == 0) return 0; break; }
        if (ch == '\n') break;
        if (n + 1 >= cap) return -1;
        buf[n++] = ch;
    }
    if (n > 0 && buf[n - 1] == '\r') n--;
    buf[n] = '\0';
    return (long)n;
}

/* Connect a TCP socket to host:port, trying every address returned
   by getaddrinfo. */
static inline int tcp_connect(const char *host, const char *port) {
    struct addrinfo hints = {0}, *res, *ai;
    hints.ai_family = AF_UNSPEC;
    hints.ai_socktype = SOCK_STREAM;
    if (getaddrinfo(host, port, &hints, &res) != 0) return -1;
    int fd = -1;
    for (ai = res; ai; ai = ai->ai_next) {
        fd = socket(ai->ai_family, ai->ai_socktype, ai->ai_protocol);
        if (fd < 0) continue;
        if (connect(fd, ai->ai_addr, ai->ai_addrlen) == 0) break;
        close(fd); fd = -1;
    }
    freeaddrinfo(res);
    return fd;
}
#endif
