/* ftp_client.c - a minimal passive-mode FTP client (Computer Networks, Lab 4)
   usage: ./ftp_client host port user password ls [dir]
          ./ftp_client host port user password get file                  */
#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include "netio.h"

static int ctrl;                              /* the control connection */

/* Read one reply, possibly multi-line ("150-..." ... "150 ..."),
   print it and return its three-digit code. */
static int reply(void) {
    char line[1024], first[4] = "";
    for (;;) {
        if (recv_line(ctrl, line, sizeof line) <= 0) {
            fprintf(stderr, "control connection lost\n");
            exit(1);
        }
        printf("<- %s\n", line);
        if (first[0] == '\0') memcpy(first, line, 3);  /* code of line 1 */
        if (strncmp(line, first, 3) == 0 && line[3] == ' ')
            return atoi(first);                        /* "ddd " ends it */
    }
}

/* Send one command terminated by CR LF (the password is not printed),
   then read and return the reply code. */
static int command(const char *fmt, ...) {
    char cmd[512];
    va_list ap;
    va_start(ap, fmt);
    vsnprintf(cmd, sizeof cmd - 2, fmt, ap);
    va_end(ap);
    printf("-> %s\n", strncmp(cmd, "PASS ", 5) == 0 ? "PASS ****" : cmd);
    strcat(cmd, "\r\n");
    if (send_all(ctrl, cmd, strlen(cmd)) < 0) { perror("send"); exit(1); }
    return reply();
}

int main(int argc, char *argv[]) {
    if (argc < 6) {
        fprintf(stderr, "usage: %s host port user password ls [dir]"
                        " | get file\n", argv[0]);
        return 1;
    }
    int get = strcmp(argv[5], "get") == 0;
    if ((ctrl = tcp_connect(argv[1], argv[2])) < 0) {
        fprintf(stderr, "cannot connect\n");
        return 1;
    }
    if (reply() != 220) return 1;                     /* service ready */
    if (command("USER %s", argv[3]) == 331 &&
        command("PASS %s", argv[4]) != 230) return 1;  /* logged in? */
    command(get ? "TYPE I" : "TYPE A");          /* image or ASCII type */

    /* PASV: the reply is 227 Entering Passive Mode (h1,h2,h3,h4,p1,p2) */
    printf("-> PASV\n");
    send_all(ctrl, "PASV\r\n", 6);
    char line[1024];
    int h1, h2, h3, h4, p1, p2;
    do {
        if (recv_line(ctrl, line, sizeof line) <= 0) return 1;
        printf("<- %s\n", line);
    } while (strncmp(line, "227 ", 4) != 0);
    char *q = strchr(line, '(');
    if (!q || sscanf(q, "(%d,%d,%d,%d,%d,%d)",
                     &h1, &h2, &h3, &h4, &p1, &p2) != 6) return 1;
    char port[8];
    snprintf(port, sizeof port, "%d", p1 * 256 + p2);
    printf("   data connection: %d.%d.%d.%d port %d*256+%d = %s\n",
           h1, h2, h3, h4, p1, p2, port);
    int data = tcp_connect(argv[1], port);   /* same host, port from PASV */
    if (data < 0) {
        fprintf(stderr, "cannot open data connection\n");
        return 1;
    }

    int code = get ? command("RETR %s", argv[6])
             : argc > 6 ? command("LIST %s", argv[6]) : command("LIST");
    if (code != 125 && code != 150) {            /* e.g. 550 no such file */
        close(data);
        command("QUIT");
        return 1;
    }
    FILE *out = get ? fopen(argv[6], "wb") : stdout;
    if (!out) { perror("fopen"); return 1; }
    char buf[4096];
    ssize_t n;
    long total = 0;
    while ((n = recv(data, buf, sizeof buf, 0)) > 0) {
        fwrite(buf, 1, (size_t)n, out);
        total += n;
    }
    close(data);              /* stream mode: end of file = connection closed */
    if (get) {
        fclose(out);
        printf("   %ld bytes written to %s\n", total, argv[6]);
    }
    reply();                                       /* 226 transfer complete */
    command("QUIT");                               /* 221 goodbye */
    close(ctrl);
    return 0;
}
