"""web_server.py - a small HTTP/1.1 server for Lab 4: cookies and caching.
usage: python3 web_server.py [port]    (listens on 127.0.0.1, default 8000)
  GET  /            a page that counts your visits with a session cookie
  GET  /notes.txt   a file with ETag, Last-Modified, Cache-Control max-age
  POST /touch       changes notes.txt, so that its ETag changes"""
import hashlib, secrets, sys, time
from email.utils import formatdate
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

sessions = {}        # session id -> visits: the state lives on the server
notes = {"text": "Lecture 4 notes, version 1\n", "mtime": time.time()}


class Handler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"               # persistent connections

    def send(self, code, body=b"", headers=()):
        self.send_response(code)
        for k, v in headers:
            self.send_header(k, v)
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        if body and self.command != "HEAD":
            self.wfile.write(body)

    def do_GET(self):
        print("   request headers:", dict(self.headers))
        if self.path == "/":
            cookies = {}
            for part in self.headers.get("Cookie", "").split(";"):
                if "=" in part:
                    k, v = part.strip().split("=", 1)
                    cookies[k] = v
            sid, extra = cookies.get("session"), []
            if sid not in sessions:     # first visit: new state, new key
                sid = secrets.token_hex(8)
                sessions[sid] = 0
                extra.append(("Set-Cookie", f"session={sid}; Path=/; "
                              "HttpOnly; SameSite=Lax"))
            sessions[sid] += 1
            body = (f"<p>Hello! This is visit number {sessions[sid]} "
                    f"of session {sid}.</p>\n").encode()
            self.send(200, body,
                      [("Content-Type", "text/html; charset=utf-8"), *extra])
        elif self.path == "/notes.txt":
            body = notes["text"].encode()
            etag = '"' + hashlib.sha1(body).hexdigest()[:12] + '"'
            if self.headers.get("If-None-Match") == etag:
                # conditional GET and the copy is still valid: no body
                self.send(304, headers=[("ETag", etag),
                                        ("Cache-Control", "max-age=30")])
                return
            modified = formatdate(notes["mtime"], usegmt=True)
            self.send(200, body, [("Content-Type", "text/plain"),
                                  ("ETag", etag),
                                  ("Last-Modified", modified),
                                  ("Cache-Control", "max-age=30")])
        else:
            self.send(404, b"not found\n", [("Content-Type", "text/plain")])

    do_HEAD = do_GET

    def do_POST(self):
        self.rfile.read(int(self.headers.get("Content-Length", 0)))
        if self.path == "/touch":
            n = int(notes["text"].split()[-1]) + 1
            notes.update(text=f"Lecture 4 notes, version {n}\n",
                         mtime=time.time())
            self.send(200, b"notes.txt changed\n",
                      [("Content-Type", "text/plain")])
        else:
            self.send(404, b"not found\n", [("Content-Type", "text/plain")])


port = int(sys.argv[1]) if len(sys.argv) > 1 else 8000
print(f"serving on http://127.0.0.1:{port}/")
ThreadingHTTPServer(("127.0.0.1", port), Handler).serve_forever()
