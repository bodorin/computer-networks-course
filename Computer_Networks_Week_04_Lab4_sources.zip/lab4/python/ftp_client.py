"""ftp_client.py - the same passive-mode session with Python's ftplib.
usage: python3 ftp_client.py host port user password ls [dir] | get file"""
import sys
from ftplib import FTP

host, port, user, password, what = sys.argv[1:6]
arg = sys.argv[6] if len(sys.argv) > 6 else ""
ftp = FTP()
ftp.set_debuglevel(1)        # print every command (*cmd*) and reply (*resp*)
ftp.connect(host, int(port))
ftp.login(user, password)
ftp.set_pasv(True)           # passive: the client opens the data connection
if what == "ls":
    ftp.retrlines("LIST " + arg if arg else "LIST")          # TYPE A, LIST
else:
    with open(arg, "wb") as f:
        ftp.retrbinary("RETR " + arg, f.write)               # TYPE I, RETR
ftp.quit()
