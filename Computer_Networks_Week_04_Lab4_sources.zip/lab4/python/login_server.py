"""login_server.py - a toy remote-login service that sends everything in
clear, like TELNET (Lab 4).
usage: python3 login_server.py [port]   (listens on 127.0.0.1, default 2323)
connect: telnet 127.0.0.1 2323   (nc 127.0.0.1 2323 shows the raw bytes)"""
import socket, sys, threading

IAC, WILL, WONT, DO, DONT = 255, 251, 252, 253, 254   # TELNET commands
ECHO = 1                                               # TELNET option 1


def read_line(conn):
    """Read one line, dropping TELNET negotiations (IAC command option)."""
    data = bytearray()
    while True:
        b = conn.recv(1)
        if not b:
            return None
        if b[0] == IAC:             # IAC DO/DONT/WILL/WONT option: skip it
            conn.recv(2)
            continue
        if b == b"\n":
            return data.decode(errors="replace").rstrip("\r")
        data += b


def session(conn, addr):
    with conn:
        conn.sendall(b"Toy login service (everything travels in clear)\r\n"
                     b"login: ")
        user = read_line(conn)
        # "I will echo": a TELNET client stops echoing what the user types
        conn.sendall(b"password: " + bytes([IAC, WILL, ECHO]))
        password = read_line(conn)
        conn.sendall(bytes([IAC, WONT, ECHO]) + b"\r\n")   # normal echo
        if user is None or password is None:
            return
        print(f"{addr[0]}:{addr[1]} logged in as {user!r}, "
              f"password {password!r}")
        conn.sendall(f"Welcome, {user}. Type a line, or 'quit'.\r\n".encode())
        while (line := read_line(conn)) not in (None, "quit"):
            conn.sendall(f"you said: {line}\r\n".encode())
        conn.sendall(b"bye\r\n")


port = int(sys.argv[1]) if len(sys.argv) > 1 else 2323
srv = socket.create_server(("127.0.0.1", port))
print(f"toy login service on 127.0.0.1:{port}")
while True:
    c, a = srv.accept()
    threading.Thread(target=session, args=(c, a), daemon=True).start()
