/* netio_win.h - helpers for TCP byte streams on Windows (Winsock 2)
   Computer Networks, Labs 3-4 */
#ifndef NETIO_WIN_H
#define NETIO_WIN_H
#include <winsock2.h>
#include <ws2tcpip.h>
#include <stdint.h>
#include <string.h>

/* Write exactly len bytes. Returns 0 on success, -1 on error. */
static inline int send_all(SOCKET s, const void *buf, size_t len) {
    const char *p = buf;
    while (len > 0) {
        int n = send(s, p, (int)len, 0);
        if (n == SOCKET_ERROR) return -1;
        p += n; len -= (size_t)n;
    }
    return 0;
}

/* Read one line ending in LF (CR LF is removed). Returns its length,
   0 if the peer closed before any byte, -1 on error or too long a line. */
static inline long recv_line(SOCKET s, char *buf, size_t cap) {
    size_t n = 0;
    for (;;) {
        char ch;
        int r = recv(s, &ch, 1, 0);
        if (r == SOCKET_ERROR) return -1;
        if (r == 0) { if (n == 0) return 0; break; }
        if (ch == '\n') break;
        if (n + 1 >= cap) return -1;
        buf[n++] = ch;
    }
    if (n > 0 && buf[n - 1] == '\r') n--;
    buf[n] = '\0';
    return (long)n;
}

/* Connect a TCP socket to host:port, trying every address returned
   by getaddrinfo. */
static inline SOCKET tcp_connect(const char *host, const char *port) {
    struct addrinfo hints = {0}, *res, *ai;
    hints.ai_family = AF_UNSPEC;
    hints.ai_socktype = SOCK_STREAM;
    if (getaddrinfo(host, port, &hints, &res) != 0) return INVALID_SOCKET;
    SOCKET s = INVALID_SOCKET;
    for (ai = res; ai; ai = ai->ai_next) {
        s = socket(ai->ai_family, ai->ai_socktype, ai->ai_protocol);
        if (s == INVALID_SOCKET) continue;
        if (connect(s, ai->ai_addr, (int)ai->ai_addrlen) == 0)
            break;
        closesocket(s); s = INVALID_SOCKET;
    }
    freeaddrinfo(res);
    return s;
}
#endif
