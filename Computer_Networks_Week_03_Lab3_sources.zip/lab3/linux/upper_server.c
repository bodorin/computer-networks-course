/* upper_server.c - line-based protocol: for every line received, reply with it in upper case.
   Lines end in "\n". Usage: ./upper_server PORT */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include "netio.h"

int main(int argc, char *argv[]) {
    if (argc != 2) { fprintf(stderr, "usage: %s PORT\n", argv[0]); return 1; }
    int lfd = socket(AF_INET, SOCK_STREAM, 0), on = 1;
    setsockopt(lfd, SOL_SOCKET, SO_REUSEADDR, &on, sizeof on);
    struct sockaddr_in addr = {0};
    addr.sin_family = AF_INET; addr.sin_addr.s_addr = htonl(INADDR_ANY);
    addr.sin_port = htons((uint16_t)atoi(argv[1]));
    if (bind(lfd, (struct sockaddr *)&addr, sizeof addr) < 0 || listen(lfd, 8) < 0) { perror("bind/listen"); return 1; }

    for (;;) {
        int cfd = accept(lfd, NULL, NULL);
        if (cfd < 0) continue;
        char buf[4096]; size_t used = 0; ssize_t n;
        while ((n = recv(cfd, buf + used, sizeof buf - used, 0)) > 0) {
            used += (size_t)n;
            char *nl;
            /* A single recv may hold part of a line, one line, or several lines. */
            while ((nl = memchr(buf, '\n', used)) != NULL) {
                size_t linelen = (size_t)(nl - buf) + 1;
                for (size_t i = 0; i < linelen; i++) buf[i] = (char)toupper((unsigned char)buf[i]);
                if (send_all(cfd, buf, linelen) < 0) break;
                memmove(buf, buf + linelen, used - linelen);   /* keep the rest for later */
                used -= linelen;
            }
            if (used == sizeof buf) { const char *e = "ERR line too long\n"; send_all(cfd, e, strlen(e)); break; }
        }
        close(cfd);
    }
}
