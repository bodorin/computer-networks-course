/* msg_client.c - sends each command-line word as one length-prefixed message.
   Usage: ./msg_client HOST PORT word1 word2 ... */
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <netdb.h>
#include "netio.h"

int main(int argc, char *argv[]) {
    if (argc < 4) { fprintf(stderr, "usage: %s HOST PORT WORD...\n", argv[0]); return 1; }
    struct addrinfo hints = {0}, *res;
    hints.ai_family = AF_UNSPEC; hints.ai_socktype = SOCK_STREAM;
    if (getaddrinfo(argv[1], argv[2], &hints, &res) != 0) { fprintf(stderr, "getaddrinfo failed\n"); return 1; }
    int fd = socket(res->ai_family, res->ai_socktype, res->ai_protocol);
    if (fd < 0 || connect(fd, res->ai_addr, res->ai_addrlen) < 0) { perror("connect"); return 1; }
    freeaddrinfo(res);
    for (int i = 3; i < argc; i++)                     /* send all messages first ... */
        if (send_msg(fd, argv[i], (uint32_t)strlen(argv[i])) < 0) { perror("send"); return 1; }
    for (int i = 3; i < argc; i++) {                   /* ... then read all replies */
        char reply[64]; long n = recv_msg(fd, reply, sizeof reply - 1);
        if (n <= 0) { fprintf(stderr, "no reply\n"); return 1; }
        reply[n] = '\0'; printf("%s -> %s\n", argv[i], reply);
    }
    close(fd);
    return 0;
}
