/* blast.c - send N bytes with ONE call to send_all, then close. Usage: ./blast HOST PORT N */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <netdb.h>
#include "netio.h"

int main(int argc, char *argv[]) {
    if (argc != 4) { fprintf(stderr, "usage: %s HOST PORT N\n", argv[0]); return 1; }
    struct addrinfo hints = {0}, *res;
    hints.ai_family = AF_UNSPEC; hints.ai_socktype = SOCK_STREAM;
    if (getaddrinfo(argv[1], argv[2], &hints, &res) != 0) { fprintf(stderr, "getaddrinfo failed\n"); return 1; }
    int fd = socket(res->ai_family, res->ai_socktype, res->ai_protocol);
    if (fd < 0 || connect(fd, res->ai_addr, res->ai_addrlen) < 0) { perror("connect"); return 1; }
    freeaddrinfo(res);
    size_t n = (size_t)atol(argv[3]);
    char *data = malloc(n); memset(data, 'x', n);
    if (send_all(fd, data, n) < 0) perror("send");
    shutdown(fd, SHUT_WR);                       /* no more data from us */
    char sink[65536]; while (recv(fd, sink, sizeof sink, 0) > 0) { }  /* drain the echo */
    close(fd); free(data);
    return 0;
}
