/* echo_server.c - iterative TCP echo server: one client at a time.
   Usage: ./echo_server PORT */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include "netio.h"

int main(int argc, char *argv[]) {
    if (argc != 2) { fprintf(stderr, "usage: %s PORT\n", argv[0]); return 1; }

    setvbuf(stdout, NULL, _IOLBF, 0);                         /* print each line at once */
    int lfd = socket(AF_INET, SOCK_STREAM, 0);               /* 1. create */
    if (lfd < 0) { perror("socket"); return 1; }
    int on = 1;
    setsockopt(lfd, SOL_SOCKET, SO_REUSEADDR, &on, sizeof on); /* allow quick restarts */

    struct sockaddr_in addr = {0};
    addr.sin_family = AF_INET;
    addr.sin_addr.s_addr = htonl(INADDR_ANY);                 /* all local addresses */
    addr.sin_port = htons((uint16_t)atoi(argv[1]));            /* host -> network byte order */
    if (bind(lfd, (struct sockaddr *)&addr, sizeof addr) < 0) { perror("bind"); return 1; } /* 2. bind */
    if (listen(lfd, 8) < 0) { perror("listen"); return 1; }  /* 3. listen, backlog 8 */
    printf("listening on port %s\n", argv[1]);

    for (;;) {
        struct sockaddr_in peer; socklen_t plen = sizeof peer;
        int cfd = accept(lfd, (struct sockaddr *)&peer, &plen); /* 4. accept: a NEW socket */
        if (cfd < 0) { perror("accept"); continue; }
        char ip[INET_ADDRSTRLEN];
        inet_ntop(AF_INET, &peer.sin_addr, ip, sizeof ip);
        printf("connection from %s:%u\n", ip, ntohs(peer.sin_port));

        char buf[65536]; ssize_t n; long total = 0;
        while ((n = recv(cfd, buf, sizeof buf, 0)) > 0) {      /* 5. read what has arrived */
            printf("  recv returned %zd bytes\n", n);
            total += n;
            if (send_all(cfd, buf, (size_t)n) < 0) { perror("send"); break; }
        }
        printf("client closed after %ld bytes\n", total);
        close(cfd);                                            /* 6. close this connection */
    }
}
