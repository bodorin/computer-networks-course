/* msg_server.c - length-prefixed messages: replies "OK <n>" to every message of n bytes.
   Usage: ./msg_server PORT */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include "netio.h"

int main(int argc, char *argv[]) {
    if (argc != 2) { fprintf(stderr, "usage: %s PORT\n", argv[0]); return 1; }
    int lfd = socket(AF_INET, SOCK_STREAM, 0), on = 1;
    setsockopt(lfd, SOL_SOCKET, SO_REUSEADDR, &on, sizeof on);
    struct sockaddr_in addr = {0};
    addr.sin_family = AF_INET; addr.sin_addr.s_addr = htonl(INADDR_ANY);
    addr.sin_port = htons((uint16_t)atoi(argv[1]));
    if (bind(lfd, (struct sockaddr *)&addr, sizeof addr) < 0 || listen(lfd, 8) < 0) { perror("bind/listen"); return 1; }
    for (;;) {
        int cfd = accept(lfd, NULL, NULL);
        if (cfd < 0) continue;
        static char msg[1 << 20]; long n;
        while ((n = recv_msg(cfd, msg, sizeof msg)) > 0) {
            char reply[64];
            int rl = snprintf(reply, sizeof reply, "OK %ld", n);
            if (send_msg(cfd, reply, (uint32_t)rl) < 0) break;
        }
        close(cfd);
    }
}
