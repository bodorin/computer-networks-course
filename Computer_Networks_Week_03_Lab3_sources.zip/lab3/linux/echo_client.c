/* echo_client.c - send each line of standard input to a TCP server, print what comes back.
   Usage: ./echo_client HOST PORT */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <netdb.h>
#include <sys/socket.h>
#include "netio.h"

int main(int argc, char *argv[]) {
    if (argc != 3) { fprintf(stderr, "usage: %s HOST PORT\n", argv[0]); return 1; }

    struct addrinfo hints = {0}, *res, *ai;
    hints.ai_family = AF_UNSPEC;          /* IPv4 or IPv6 */
    hints.ai_socktype = SOCK_STREAM;      /* TCP */
    int err = getaddrinfo(argv[1], argv[2], &hints, &res);
    if (err) { fprintf(stderr, "getaddrinfo: %s\n", gai_strerror(err)); return 1; }

    int fd = -1;
    for (ai = res; ai != NULL; ai = ai->ai_next) {          /* try each address in turn */
        fd = socket(ai->ai_family, ai->ai_socktype, ai->ai_protocol);
        if (fd < 0) continue;
        if (connect(fd, ai->ai_addr, ai->ai_addrlen) == 0) break;
        close(fd); fd = -1;
    }
    freeaddrinfo(res);
    if (fd < 0) { perror("connect"); return 1; }

    char line[1024], reply[1024];
    while (fgets(line, sizeof line, stdin) != NULL) {
        size_t len = strlen(line);
        if (send_all(fd, line, len) < 0) { perror("send"); break; }
        /* The echo has the same length as what we sent, but may arrive in pieces. */
        int r = recv_all(fd, reply, len);
        if (r <= 0) { fprintf(stderr, r == 0 ? "server closed the connection\n" : "recv failed\n"); break; }
        fwrite(reply, 1, len, stdout);
    }
    close(fd);
    return 0;
}
