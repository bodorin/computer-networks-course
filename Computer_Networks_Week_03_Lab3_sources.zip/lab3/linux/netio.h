/* netio.h - helpers for TCP byte streams (Computer Networks, Lab 3) */
#ifndef NETIO_H
#define NETIO_H
#include <stdint.h>
#include <errno.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <sys/socket.h>

/* Write exactly len bytes. Returns 0 on success, -1 on error. */
static inline int send_all(int fd, const void *buf, size_t len) {
    const char *p = buf;
    while (len > 0) {
        ssize_t n = send(fd, p, len, 0);
        if (n < 0) { if (errno == EINTR) continue; return -1; }
        p += n; len -= (size_t)n;
    }
    return 0;
}

/* Read exactly len bytes. Returns 1 on success, 0 if the peer closed first, -1 on error. */
static inline int recv_all(int fd, void *buf, size_t len) {
    char *p = buf;
    while (len > 0) {
        ssize_t n = recv(fd, p, len, 0);
        if (n < 0) { if (errno == EINTR) continue; return -1; }
        if (n == 0) return 0;
        p += n; len -= (size_t)n;
    }
    return 1;
}

/* Length-prefixed messages: 4-byte length in network byte order, then the payload. */
static inline int send_msg(int fd, const void *buf, uint32_t len) {
    uint32_t netlen = htonl(len);
    if (send_all(fd, &netlen, sizeof netlen) < 0) return -1;
    return send_all(fd, buf, len);
}

/* Returns the payload length, 0 if the peer closed, -1 on error or if the message exceeds cap. */
static inline long recv_msg(int fd, void *buf, uint32_t cap) {
    uint32_t netlen;
    int r = recv_all(fd, &netlen, sizeof netlen);
    if (r <= 0) return r;
    uint32_t len = ntohl(netlen);
    if (len > cap) return -1;
    r = recv_all(fd, buf, len);
    return r <= 0 ? -1 : (long)len;
}
#endif
