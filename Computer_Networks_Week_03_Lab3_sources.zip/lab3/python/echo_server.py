"""echo_server.py - iterative TCP echo server (Linux and Windows). Usage: python echo_server.py PORT"""
import socket, sys

port = int(sys.argv[1])
with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as ls:
    ls.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    ls.bind(("127.0.0.1", port))
    ls.listen(8)
    print(f"listening on 127.0.0.1:{port}", flush=True)
    while True:
        conn, (ip, cport) = ls.accept()          # a NEW socket for this client
        print(f"connection from {ip}:{cport}", flush=True)
        with conn:
            total = 0
            while data := conn.recv(65536):      # b"" means the client closed
                print(f"  recv returned {len(data)} bytes", flush=True)
                total += len(data)
                conn.sendall(data)               # sendall = send_all in C
            print(f"client closed after {total} bytes", flush=True)
