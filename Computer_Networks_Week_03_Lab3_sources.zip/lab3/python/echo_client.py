"""echo_client.py - send lines from standard input, print the echo. Usage: python echo_client.py HOST PORT"""
import socket, sys

def recv_all(sock, n):
    """Read exactly n bytes, or raise if the peer closes first."""
    chunks = []
    while n > 0:
        data = sock.recv(n)
        if not data:
            raise ConnectionError("server closed the connection")
        chunks.append(data)
        n -= len(data)
    return b"".join(chunks)

with socket.create_connection((sys.argv[1], int(sys.argv[2]))) as s:
    for line in sys.stdin:
        data = line.encode()
        s.sendall(data)
        print(recv_all(s, len(data)).decode(), end="")
