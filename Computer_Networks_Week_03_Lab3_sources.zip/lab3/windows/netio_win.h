/* netio_win.h - helpers for TCP byte streams on Windows (Winsock 2) - Computer Networks, Lab 3 */
#ifndef NETIO_WIN_H
#define NETIO_WIN_H
#include <winsock2.h>
#include <ws2tcpip.h>
#include <stdint.h>

/* Write exactly len bytes. Returns 0 on success, -1 on error. */
static inline int send_all(SOCKET s, const void *buf, size_t len) {
    const char *p = buf;
    while (len > 0) {
        int n = send(s, p, (int)len, 0);
        if (n == SOCKET_ERROR) return -1;
        p += n; len -= (size_t)n;
    }
    return 0;
}

/* Read exactly len bytes. Returns 1 on success, 0 if the peer closed first, -1 on error. */
static inline int recv_all(SOCKET s, void *buf, size_t len) {
    char *p = buf;
    while (len > 0) {
        int n = recv(s, p, (int)len, 0);
        if (n == SOCKET_ERROR) return -1;
        if (n == 0) return 0;
        p += n; len -= (size_t)n;
    }
    return 1;
}

static inline int send_msg(SOCKET s, const void *buf, uint32_t len) {
    uint32_t netlen = htonl(len);
    if (send_all(s, &netlen, sizeof netlen) < 0) return -1;
    return send_all(s, buf, len);
}

static inline long recv_msg(SOCKET s, void *buf, uint32_t cap) {
    uint32_t netlen;
    int r = recv_all(s, &netlen, sizeof netlen);
    if (r <= 0) return r;
    uint32_t len = ntohl(netlen);
    if (len > cap) return -1;
    r = recv_all(s, buf, len);
    return r <= 0 ? -1 : (long)len;
}
#endif
