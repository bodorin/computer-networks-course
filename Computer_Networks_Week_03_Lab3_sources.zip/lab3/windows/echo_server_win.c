/* echo_server_win.c - Winsock version of echo_server.c (iterative, one client at a time).
   Build:  gcc echo_server_win.c -o echo_server.exe -lws2_32
   Usage:  echo_server.exe PORT */
#include <stdio.h>
#include <stdlib.h>
#include "netio_win.h"
#ifdef _MSC_VER
#pragma comment(lib, "ws2_32.lib")
#endif

int main(int argc, char *argv[]) {
    if (argc != 2) { fprintf(stderr, "usage: %s PORT\n", argv[0]); return 1; }
    setvbuf(stdout, NULL, _IONBF, 0);
    WSADATA wsa;
    if (WSAStartup(MAKEWORD(2, 2), &wsa) != 0) { fprintf(stderr, "WSAStartup failed\n"); return 1; }

    SOCKET ls = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
    if (ls == INVALID_SOCKET) { fprintf(stderr, "socket: %d\n", WSAGetLastError()); return 1; }

    struct sockaddr_in addr = {0};
    addr.sin_family = AF_INET;
    /* Loopback only: avoids the Windows Firewall prompt. Use INADDR_ANY to accept other machines. */
    addr.sin_addr.s_addr = htonl(INADDR_LOOPBACK);
    addr.sin_port = htons((u_short)atoi(argv[1]));
    if (bind(ls, (struct sockaddr *)&addr, sizeof addr) == SOCKET_ERROR) { fprintf(stderr, "bind: %d\n", WSAGetLastError()); return 1; }
    if (listen(ls, 8) == SOCKET_ERROR) { fprintf(stderr, "listen: %d\n", WSAGetLastError()); return 1; }
    printf("listening on 127.0.0.1:%s\n", argv[1]);

    for (;;) {
        struct sockaddr_in peer; int plen = sizeof peer;
        SOCKET cs = accept(ls, (struct sockaddr *)&peer, &plen);
        if (cs == INVALID_SOCKET) { fprintf(stderr, "accept: %d\n", WSAGetLastError()); continue; }
        char ip[INET_ADDRSTRLEN];
        inet_ntop(AF_INET, &peer.sin_addr, ip, sizeof ip);
        printf("connection from %s:%u\n", ip, ntohs(peer.sin_port));

        char buf[65536]; int n; long total = 0;
        while ((n = recv(cs, buf, sizeof buf, 0)) > 0) {
            printf("  recv returned %d bytes\n", n);
            total += n;
            if (send_all(cs, buf, (size_t)n) < 0) break;
        }
        printf("client closed after %ld bytes\n", total);
        closesocket(cs);
    }
}
