/* echo_client_win.c - Winsock version of echo_client.c.
   Build:  gcc echo_client_win.c -o echo_client.exe -lws2_32     (MinGW-w64)
      or:  cl echo_client_win.c ws2_32.lib                         (Visual Studio)
   Usage:  echo_client.exe HOST PORT */
#include <stdio.h>
#include <string.h>
#include "netio_win.h"
#ifdef _MSC_VER
#pragma comment(lib, "ws2_32.lib")
#endif

int main(int argc, char *argv[]) {
    if (argc != 3) { fprintf(stderr, "usage: %s HOST PORT\n", argv[0]); return 1; }
    WSADATA wsa;
    if (WSAStartup(MAKEWORD(2, 2), &wsa) != 0) { fprintf(stderr, "WSAStartup failed\n"); return 1; }

    struct addrinfo hints = {0}, *res, *ai;
    hints.ai_family = AF_UNSPEC; hints.ai_socktype = SOCK_STREAM;
    int err = getaddrinfo(argv[1], argv[2], &hints, &res);
    if (err) { fprintf(stderr, "getaddrinfo failed: %d\n", err); WSACleanup(); return 1; }

    SOCKET s = INVALID_SOCKET;
    for (ai = res; ai != NULL; ai = ai->ai_next) {
        s = socket(ai->ai_family, ai->ai_socktype, ai->ai_protocol);
        if (s == INVALID_SOCKET) continue;
        if (connect(s, ai->ai_addr, (int)ai->ai_addrlen) == 0) break;
        closesocket(s); s = INVALID_SOCKET;
    }
    freeaddrinfo(res);
    if (s == INVALID_SOCKET) { fprintf(stderr, "connect failed: error %d\n", WSAGetLastError()); WSACleanup(); return 1; }

    char line[1024], reply[1024];
    while (fgets(line, sizeof line, stdin) != NULL) {
        size_t len = strlen(line);
        if (send_all(s, line, len) < 0) { fprintf(stderr, "send failed: %d\n", WSAGetLastError()); break; }
        int r = recv_all(s, reply, len);
        if (r <= 0) { fprintf(stderr, r == 0 ? "server closed the connection\n" : "recv failed\n"); break; }
        fwrite(reply, 1, len, stdout);
    }
    closesocket(s);
    WSACleanup();
    return 0;
}
